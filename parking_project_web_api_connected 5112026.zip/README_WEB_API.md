# C + HTML 웹 연결 버전 안내

이 버전은 기존 터미널용 `parking_system`은 유지하고, 웹에서 호출할 수 있는 `parking_api.cgi`를 추가한 버전입니다.

## 추가/수정된 핵심 파일

- `parking_api.c` : HTML `fetch()` 요청을 받아 C 데이터 파일을 읽고/수정한 뒤 JSON으로 응답하는 CGI 진입점
- `parking.h` : 웹 API용 함수 선언 추가
- `reservation.c` : 웹 예약 생성/조회/예약번호 찾기 API 함수 추가
- `parking.c` : 웹 입차/출차/정산 미리보기 API 함수 추가
- `admin.c` : 웹 관리자 입차시간 수정 API 함수 추가
- `payment.c` : 웹 관리자 매출 집계 API 함수 추가
- `Makefile` : `parking_system`과 `parking_api.cgi`를 같이 빌드하도록 수정
- `index.html` : 기존 관리자 타워 페이지 HTML을 C CGI API 호출 방식으로 수정

## 빌드

```bash
make clean
make
```

빌드 결과:

- `parking_system` : 기존 터미널용 실행파일
- `parking_api.cgi` : 웹 HTML에서 호출하는 CGI 실행파일

## API 경로 설정

`index.html` 안에 아래 값이 있습니다.

```js
const API_URL = './parking_api.cgi';
```

HTML과 `parking_api.cgi`를 같은 CGI 실행 가능 폴더에 둘 경우 그대로 쓰면 됩니다.
Apache에서 `/cgi-bin/`을 쓰면 아래처럼 바꾸면 됩니다.

```js
const API_URL = '/cgi-bin/parking_api.cgi';
```

## 지원하는 action

HTML은 다음 action을 호출합니다.

- `reserve` : 예약 생성
- `entry` : 예약번호/차량번호 기반 입차 처리
- `status` : 예약번호 상태 조회
- `find` : 차량번호/전화번호로 예약번호 찾기
- `settle_preview` : 출차 전 요금 확인
- `exit` : 결제/출차/영수증 저장
- `admin_summary` : 관리자 메인 요약
- `admin_tower` : 타워별 입차/예약/매출 상세
- `update_entry_time` : 관리자 입차시간 수정

## 주의

그냥 `index.html`을 더블클릭해서 열면 CGI가 실행되지 않습니다. CGI 실행이 가능한 서버에서 열어야 합니다.
수업 시연용으로는 WSL/Ubuntu에서 Apache CGI 설정을 켜거나, 교수님이 요구한 방식에 맞춰 CGI 실행 환경을 잡아야 합니다.
