# 웹-C 데이터 연결 최종 정리

이 버전은 HTML의 관리자 더미 데이터(`adminTowerData`)를 제거하고, 주차타워 A/B/C 기준을 C 데이터 기준으로 맞춘 버전입니다.

## 데이터 기준

- A Tower = `tower_id 1`
- B Tower = `tower_id 2`
- C Tower = `tower_id 3`

HTML은 화면만 담당합니다. 실제 데이터는 C가 관리합니다.

- 예약: `data/reservations.dat`
- 입차: `data/parking.dat`
- 출차/매출/영수증: `data/receipt_records.dat`
- 타워 기본 정보: `data/towers.dat`

## 연결된 API

- `reserve`: 예약 생성
- `entry`: 입차 처리
- `status`: 예약/입차 조회
- `find`: 차량번호+전화번호로 예약번호 찾기
- `settle_preview`: 출차 전 요금 확인
- `exit`: 결제/출차/영수증 저장
- `admin_summary`: 관리자 메인
- `admin_tower`: A/B/C 타워별 상세
- `update_entry_time`: 관리자 입차시간 수정
- `tower_overview`: 안내 페이지/예약 타워 선택용 타워 현황

## 빌드

```bash
make clean
make
```

생성 파일:

- `parking_system`: 기존 터미널 실행용
- `parking_api.cgi`: 웹 연결용 C CGI

## 간단 실행

```bash
./run_python_cgi.sh
```

또는 `RUN_MONGOOSE.txt`를 참고해서 Mongoose로 실행하세요.
