#!/bin/bash
set -e
make clean
make
mkdir -p data
chmod +x parking_api.cgi
python3 -m http.server --cgi 8000
