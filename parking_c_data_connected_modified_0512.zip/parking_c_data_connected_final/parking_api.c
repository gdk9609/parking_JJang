#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include "parking.h"

static char *request_data = NULL;

static void print_header(void) {
    printf("Content-Type: application/json; charset=utf-8\r\n");
    printf("Access-Control-Allow-Origin: *\r\n\r\n");
}

static void json_escape_print(const char *s) {
    putchar('"');
    if (s) {
        for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
            switch (*p) {
                case '"': printf("\\\""); break;
                case '\\': printf("\\\\"); break;
                case '\b': printf("\\b"); break;
                case '\f': printf("\\f"); break;
                case '\n': printf("\\n"); break;
                case '\r': printf("\\r"); break;
                case '\t': printf("\\t"); break;
                default:
                    if (*p < 0x20) printf("\\u%04x", *p);
                    else putchar(*p);
            }
        }
    }
    putchar('"');
}

static void print_error(const char *message) {
    printf("{\"success\":false,\"message\":");
    json_escape_print(message ? message : "요청 처리 중 오류가 발생했습니다.");
    printf("}");
}

static int hex_value(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

static void url_decode(char *s) {
    char *src = s;
    char *dst = s;
    while (*src) {
        if (*src == '+') {
            *dst++ = ' ';
            src++;
        } else if (*src == '%' && isxdigit((unsigned char)src[1]) && isxdigit((unsigned char)src[2])) {
            int hi = hex_value(src[1]);
            int lo = hex_value(src[2]);
            *dst++ = (char)((hi << 4) | lo);
            src += 3;
        } else {
            *dst++ = *src++;
        }
    }
    *dst = '\0';
}

static const char *get_param(const char *name) {
    static char value[2048];
    value[0] = '\0';
    if (!request_data || !name) return value;
    size_t name_len = strlen(name);
    const char *p = request_data;
    while (*p) {
        const char *key_start = p;
        const char *eq = strchr(key_start, '=');
        const char *amp = strchr(key_start, '&');
        if (!amp) amp = key_start + strlen(key_start);
        if (eq && eq < amp && (size_t)(eq - key_start) == name_len && strncmp(key_start, name, name_len) == 0) {
            size_t len = (size_t)(amp - eq - 1);
            if (len >= sizeof(value)) len = sizeof(value) - 1;
            memcpy(value, eq + 1, len);
            value[len] = '\0';
            url_decode(value);
            return value;
        }
        if (*amp == '&') p = amp + 1;
        else break;
    }
    return value;
}

static void copy_param(char *dst, size_t dst_size, const char *name) {
    if (!dst || dst_size == 0) return;
    const char *v = get_param(name);
    snprintf(dst, dst_size, "%s", v ? v : "");
}

static char *read_request(void) {
    const char *method = getenv("REQUEST_METHOD");
    if (method && strcmp(method, "POST") == 0) {
        const char *len_str = getenv("CONTENT_LENGTH");
        long len = len_str ? strtol(len_str, NULL, 10) : 0;
        if (len < 0) len = 0;
        if (len > 100000) len = 100000;
        char *buf = calloc((size_t)len + 1, 1);
        if (!buf) return NULL;
        if (len > 0) fread(buf, 1, (size_t)len, stdin);
        return buf;
    }
    const char *qs = getenv("QUERY_STRING");
    if (!qs) qs = "";
    char *buf = malloc(strlen(qs) + 1);
    if (!buf) return NULL;
    strcpy(buf, qs);
    return buf;
}

static int parse_tower_id(const char *s) {
    if (!s || !*s) return 0;
    if (strcmp(s, "1") == 0 || s[0] == 'A' || s[0] == 'a') return 1;
    if (strcmp(s, "2") == 0 || s[0] == 'B' || s[0] == 'b') return 2;
    if (strcmp(s, "3") == 0 || s[0] == 'C' || s[0] == 'c') return 3;
    return atoi(s);
}

static int parse_car_type(const char *s) {
    if (!s || !*s) return 0;
    if (strcmp(s, "1") == 0 || strcmp(s, "경차") == 0) return CAR_COMPACT;
    if (strcmp(s, "2") == 0 || strcmp(s, "중형차") == 0) return CAR_MIDSIZE;
    if (strcmp(s, "3") == 0 || strcmp(s, "SUV") == 0 || strcmp(s, "suv") == 0) return CAR_SUV;
    if (strcmp(s, "4") == 0 || strcmp(s, "대형차") == 0) return CAR_LARGE;
    if (strcmp(s, "5") == 0 || strcmp(s, "전기차") == 0) return CAR_EV;
    return atoi(s);
}

static const char *tower_key(int tower_id) {
    if (tower_id == 1) return "A";
    if (tower_id == 2) return "B";
    if (tower_id == 3) return "C";
    return "?";
}

static void format_money(int value, char *buf, size_t size) {
    snprintf(buf, size, "%d원", value);
}

static void print_time_field(const char *name, time_t t) {
    char buf[64];
    format_time(t, buf, sizeof(buf));
    printf("\"%s\":", name);
    json_escape_print(buf);
}

static int count_parking_for_tower(int tower_id) {
    int count = count_records(PARKING_FILE, sizeof(ParkingRecord));
    int n = 0;
    for (int i = 0; i < count; i++) {
        ParkingRecord p;
        if (read_record_at(PARKING_FILE, i, &p, sizeof(p)) == 0 && p.tower_id == tower_id) n++;
    }
    return n;
}

static int count_reserved_for_tower(int tower_id) {
    int count = count_records(RESERVATIONS_FILE, sizeof(Reservation));
    int n = 0;
    for (int i = 0; i < count; i++) {
        Reservation r;
        if (read_record_at(RESERVATIONS_FILE, i, &r, sizeof(r)) == 0 && r.tower_id == tower_id && r.status == RES_RESERVED) n++;
    }
    return n;
}

static void tower_status_text(int used, int capacity, const char **status, const char **status_class) {
    if (capacity <= 0 || used >= capacity) { *status = "만차"; *status_class = "full"; return; }
    double ratio = capacity > 0 ? (double)used / (double)capacity : 1.0;
    if (ratio < 0.4) { *status = "여유"; *status_class = "good"; }
    else if (ratio < 0.8) { *status = "보통"; *status_class = "normal"; }
    else { *status = "혼잡"; *status_class = "busy"; }
}

static void print_reservation_json_fields(const Reservation *r) {
    char towername[32];
    snprintf(towername, sizeof(towername), "%c Tower", 'A' + r->tower_id - 1);
    printf(",\"reservationNo\":"); json_escape_print(r->code);
    printf(",\"carNumber\":"); json_escape_print(r->car_number);
    printf(",\"phoneNumber\":"); json_escape_print(r->phone);
    printf(",\"carType\":"); json_escape_print(car_type_name(r->car_type));
    printf(",\"carTypeId\":%d", r->car_type);
    printf(",\"towerId\":%d", r->tower_id);
    printf(",\"parkingTower\":"); json_escape_print(towername);
}

static void action_reserve(void) {
    char err[256] = "";
    char car_number[MAX_NAME], phone[MAX_PHONE], car_type_text[64], tower_text[64];
    Reservation r;
    copy_param(car_number, sizeof(car_number), "carNumber");
    copy_param(phone, sizeof(phone), "phoneNumber");
    copy_param(car_type_text, sizeof(car_type_text), "carType");
    copy_param(tower_text, sizeof(tower_text), "towerId");
    if (!*tower_text) copy_param(tower_text, sizeof(tower_text), "tower");
    int car_type = parse_car_type(car_type_text);
    int tower_id = parse_tower_id(tower_text);

    if (!api_create_reservation(car_number, phone, car_type, tower_id, &r, err, sizeof(err))) {
        print_error(err);
        return;
    }

    char money[32];
    format_money(r.deposit, money, sizeof(money));
    printf("{\"success\":true");
    print_reservation_json_fields(&r);
    printf(",\"operatingHours\":"); json_escape_print(DEFAULT_OPERATING_HOURS);
    printf(","); print_time_field("reserveTime", r.reserved_at);
    printf(",\"limitTime\":\"20분\"");
    printf(",\"deposit\":"); json_escape_print(money);
    printf("}");
}

static void action_entry(void) {
    char err[256] = "";
    char code[MAX_CODE], car_number[MAX_NAME];
    ParkingRecord p;
    copy_param(code, sizeof(code), "reservationNo");
    if (!*code) copy_param(code, sizeof(code), "code");
    copy_param(car_number, sizeof(car_number), "carNumber");
    if (!api_entry_car(code, car_number, &p, err, sizeof(err))) {
        print_error(err);
        return;
    }
    char towername[32];
    snprintf(towername, sizeof(towername), "%c Tower", 'A' + p.tower_id - 1);
    printf("{\"success\":true");
    printf(",\"reservationNo\":"); json_escape_print(p.reservation_code);
    printf(",\"carNumber\":"); json_escape_print(p.car_number);
    printf(",\"phoneNumber\":"); json_escape_print(p.phone);
    printf(",\"carType\":"); json_escape_print(car_type_name(p.car_type));
    printf(",\"carTypeId\":%d", p.car_type);
    printf(",\"towerId\":%d", p.tower_id);
    printf(",\"parkingTower\":"); json_escape_print(towername);
    printf(","); print_time_field("entryTime", p.entry_time);
    printf("}");
}

static void print_status_json(int status, const Reservation *r, const ParkingRecord *p, int remaining) {
    printf("{\"success\":true");
    if (status == RES_RESERVED && r) {
        printf(",\"status\":\"reserved\",\"statusText\":\"예약 완료\"");
        print_reservation_json_fields(r);
        printf(","); print_time_field("reserveTime", r->reserved_at);
        printf(",\"remainingSeconds\":%d", remaining);
        char rem[64]; snprintf(rem, sizeof(rem), "%d분 %d초", remaining / 60, remaining % 60);
        printf(",\"remainingText\":"); json_escape_print(rem);
    } else if (status == RES_ENTERED && p) {
        int elapsed = seconds_to_minutes_ceil(p->entry_time, now_time());
        int current_fee = calculate_parking_fee(elapsed);
        char dur[64], feeText[32], towername[32];
        format_duration_minutes(elapsed, dur, sizeof(dur));
        format_money(current_fee, feeText, sizeof(feeText));
        snprintf(towername, sizeof(towername), "%c Tower", 'A' + p->tower_id - 1);
        printf(",\"status\":\"entered\",\"statusText\":\"입차 완료\"");
        printf(",\"reservationNo\":"); json_escape_print(p->reservation_code);
        printf(",\"carNumber\":"); json_escape_print(p->car_number);
        printf(",\"phoneNumber\":"); json_escape_print(p->phone);
        printf(",\"carType\":"); json_escape_print(car_type_name(p->car_type));
        printf(",\"carTypeId\":%d", p->car_type);
        printf(",\"towerId\":%d", p->tower_id);
        printf(",\"parkingTower\":"); json_escape_print(towername);
        printf(","); print_time_field("entryTime", p->entry_time);
        printf(",\"elapsedText\":"); json_escape_print(dur);
        printf(",\"currentFee\":%d", current_fee);
        printf(",\"currentFeeText\":"); json_escape_print(feeText);
    }
    printf("}");
}

static void action_status(void) {
    char err[256] = "";
    char code[MAX_CODE];
    Reservation r;
    ParkingRecord p;
    int status = 0, remaining = 0;
    copy_param(code, sizeof(code), "reservationNo");
    if (!*code) copy_param(code, sizeof(code), "code");
    if (!api_get_active_status_by_code(code, &r, &p, &status, &remaining, err, sizeof(err))) {
        print_error(err);
        return;
    }
    print_status_json(status, &r, &p, remaining);
}

static void action_find(void) {
    char err[256] = "";
    char car_number[MAX_NAME], phone[MAX_PHONE];
    Reservation r;
    ParkingRecord p;
    int status = 0, remaining = 0;
    copy_param(car_number, sizeof(car_number), "carNumber");
    copy_param(phone, sizeof(phone), "phoneNumber");
    if (!api_find_active_by_identity(car_number, phone, &r, &p, &status, &remaining, err, sizeof(err))) {
        print_error(err);
        return;
    }
    print_status_json(status, &r, &p, remaining);
}

static void print_payment_json(const Payment *p, int completed) {
    char duration[64], money[32];
    format_duration_minutes(p->total_minutes, duration, sizeof(duration));
    printf("{\"success\":true");
    if (completed) printf(",\"completed\":true");
    printf(",\"reservationNo\":"); json_escape_print(p->reservation_code);
    printf(",\"receiptNo\":"); json_escape_print(p->receipt_no);
    printf(",\"carNumber\":"); json_escape_print(p->car_number);
    printf(",\"phoneNumber\":"); json_escape_print(p->phone);
    printf(",\"carType\":"); json_escape_print(car_type_name(p->car_type));
    printf(",\"towerId\":%d", p->tower_id);
    printf(",\"parkingTower\":"); char towername[32]; snprintf(towername, sizeof(towername), "%c Tower", 'A' + p->tower_id - 1); json_escape_print(towername);
    printf(","); print_time_field("entryTime", p->entry_time);
    printf(","); print_time_field("exitTime", p->exit_time);
    printf(",\"durationText\":"); json_escape_print(duration);
    printf(",\"totalMinutes\":%d", p->total_minutes);
    printf(",\"chargedMinutes\":%d", p->charged_minutes);
    printf(",\"parkingFee\":%d", p->parking_fee);
    printf(",\"depositUsed\":%d", p->deposit_used);
    printf(",\"finalFee\":%d", p->final_fee);
    format_money(p->parking_fee, money, sizeof(money)); printf(",\"parkingFeeText\":"); json_escape_print(money);
    format_money(p->deposit_used, money, sizeof(money)); printf(",\"depositUsedText\":"); json_escape_print(money);
    format_money(p->final_fee, money, sizeof(money)); printf(",\"finalFeeText\":"); json_escape_print(money);
    printf(",\"method\":"); json_escape_print(p->method);
    printf("}");
}

static void action_settle_preview(void) {
    char err[256] = "";
    char code[MAX_CODE];
    Payment p;
    copy_param(code, sizeof(code), "reservationNo");
    if (!*code) copy_param(code, sizeof(code), "code");
    if (!api_preview_exit_fee(code, &p, err, sizeof(err))) {
        print_error(err);
        return;
    }
    print_payment_json(&p, 0);
}

static void action_exit(void) {
    char err[256] = "";
    char code[MAX_CODE], method[MAX_METHOD];
    Payment p;
    copy_param(code, sizeof(code), "reservationNo");
    if (!*code) copy_param(code, sizeof(code), "code");
    copy_param(method, sizeof(method), "method");
    if (!api_exit_car(code, method, &p, err, sizeof(err))) {
        print_error(err);
        return;
    }
    print_payment_json(&p, 1);
}

static void action_fee_calc(void) {
    char err[256] = "";
    char entry[64], exit_time[64];
    int total = 0, charged = 0, fee = 0;
    copy_param(entry, sizeof(entry), "entryTime");
    copy_param(exit_time, sizeof(exit_time), "exitTime");
    if (!api_calculate_fee(entry, exit_time, &total, &charged, &fee, err, sizeof(err))) {
        print_error(err);
        return;
    }
    char duration[64], charged_text[64], money[32];
    format_duration_minutes(total, duration, sizeof(duration));
    format_duration_minutes(charged, charged_text, sizeof(charged_text));
    printf("{\"success\":true");
    printf(",\"totalMinutes\":%d", total);
    printf(",\"chargedMinutes\":%d", charged);
    printf(",\"durationText\":"); json_escape_print(duration);
    printf(",\"chargedText\":"); json_escape_print(charged_text);
    printf(",\"fee\":%d", fee);
    format_money(fee, money, sizeof(money)); printf(",\"feeText\":"); json_escape_print(money);
    printf(",\"baseFee\":%d", BASE_FEE);
    printf(",\"extraFee\":%d", fee > BASE_FEE ? fee - BASE_FEE : 0);
    printf("}");
}

static void action_tower_overview(void) {
    expire_old_reservations();
    rebuild_tower_current_from_reservations();
    printf("{\"success\":true,\"baseFee\":%d,\"extraUnitMinutes\":%d,\"extraUnitFee\":%d,\"towers\":[", BASE_FEE, EXTRA_UNIT_MINUTES, EXTRA_UNIT_FEE);
    int printed = 0;
    for (int id = 1; id <= 3; id++) {
        ParkingTower t;
        if (!get_tower_by_id(id, &t, NULL)) continue;
        int entered = count_parking_for_tower(id);
        int reserved = count_reserved_for_tower(id);
        int available_total = 0;
        for (int type = 1; type <= CAR_TYPE_COUNT; type++) available_total += get_available_slots(id, type);
        const char *status = "보통", *status_class = "normal";
        tower_status_text(entered + reserved, t.total_capacity, &status, &status_class);
        if (printed++) printf(",");
        printf("{\"key\":"); json_escape_print(tower_key(id));
        printf(",\"id\":%d,\"name\":", id); json_escape_print(t.name);
        printf(",\"capacity\":%d", t.total_capacity);
        printf(",\"usedTotal\":%d", entered + reserved);
        printf(",\"availableTotal\":%d", available_total);
        printf(",\"enteredCount\":%d", entered);
        printf(",\"reservedCount\":%d", reserved);
        printf(",\"operatingHours\":"); json_escape_print(t.operating_hours);
        printf(",\"status\":"); json_escape_print(status);
        printf(",\"statusClass\":"); json_escape_print(status_class);
        printf(",\"carTypes\":[");
        for (int type = 1; type <= CAR_TYPE_COUNT; type++) {
            if (type > 1) printf(",");
            int reserved_type = count_active_reservations(id, type);
            int entered_type = t.current[type];
            int used = entered_type + reserved_type;
            int available = get_available_slots(id, type);
            printf("{\"id\":%d,\"name\":", type); json_escape_print(car_type_name(type));
            printf(",\"capacity\":%d,\"entered\":%d,\"reserved\":%d,\"used\":%d,\"available\":%d}",
                   t.capacity[type], entered_type, reserved_type, used, available);
        }
        printf("]}");
    }
    printf("]}");
}

static void action_admin_summary(void) {
    expire_old_reservations();
    rebuild_tower_current_from_reservations();
    int total_sales = 0;
    int tower_sales[4] = {0};
    api_get_sales_summary(&total_sales, tower_sales);
    int total_entered = count_records(PARKING_FILE, sizeof(ParkingRecord));
    int total_reserved = count_records(RESERVATIONS_FILE, sizeof(Reservation));

    printf("{\"success\":true,\"totalEntered\":%d,\"totalReserved\":%d,\"totalSales\":%d,\"towers\":[", total_entered, total_reserved, total_sales);
    for (int id = 1; id <= 3; id++) {
        ParkingTower t;
        if (!get_tower_by_id(id, &t, NULL)) continue;
        int entered = count_parking_for_tower(id);
        int reserved = count_reserved_for_tower(id);
        const char *status = "보통", *status_class = "normal";
        tower_status_text(entered + reserved, t.total_capacity, &status, &status_class);
        if (id > 1) printf(",");
        printf("{\"key\":"); json_escape_print(tower_key(id));
        printf(",\"id\":%d,\"name\":", id); json_escape_print(t.name);
        printf(",\"capacity\":%d,\"usedTotal\":%d,\"enteredCount\":%d,\"reservedCount\":%d,\"sales\":%d",
               t.total_capacity, entered + reserved, entered, reserved, tower_sales[id]);
        printf(",\"status\":"); json_escape_print(status);
        printf(",\"statusClass\":"); json_escape_print(status_class);
        printf("}");
    }
    printf("]}");
}

static void action_admin_tower(void) {
    expire_old_reservations();
    rebuild_tower_current_from_reservations();
    char tower_text[64];
    copy_param(tower_text, sizeof(tower_text), "towerId");
    if (!*tower_text) copy_param(tower_text, sizeof(tower_text), "tower");
    int tower_id = parse_tower_id(tower_text);
    ParkingTower t;
    if (!get_tower_by_id(tower_id, &t, NULL)) {
        print_error("존재하지 않는 주차타워입니다.");
        return;
    }
    int total_sales = 0, tower_sales[4] = {0};
    api_get_sales_summary(&total_sales, tower_sales);
    int entered = count_parking_for_tower(tower_id);
    int reserved = count_reserved_for_tower(tower_id);
    const char *status = "보통", *status_class = "normal";
    tower_status_text(entered + reserved, t.total_capacity, &status, &status_class);

    printf("{\"success\":true,\"tower\":{");
    printf("\"key\":"); json_escape_print(tower_key(tower_id));
    printf(",\"id\":%d,\"name\":", tower_id); json_escape_print(t.name);
    printf(",\"capacity\":%d,\"usedTotal\":%d,\"sales\":%d,\"status\":", t.total_capacity, entered + reserved, tower_sales[tower_id]); json_escape_print(status);
    printf(",\"statusClass\":"); json_escape_print(status_class);
    printf("},\"entered\":[");

    int count = count_records(PARKING_FILE, sizeof(ParkingRecord));
    int first = 1;
    for (int i = 0; i < count; i++) {
        ParkingRecord p;
        if (read_record_at(PARKING_FILE, i, &p, sizeof(p)) == 0 && p.tower_id == tower_id) {
            int elapsed = seconds_to_minutes_ceil(p.entry_time, now_time());
            int fee = calculate_parking_fee(elapsed);
            char dur[64]; format_duration_minutes(elapsed, dur, sizeof(dur));
            if (!first) printf(",");
            first = 0;
            printf("{\"reservationNo\":"); json_escape_print(p.reservation_code);
            printf(",\"carNumber\":"); json_escape_print(p.car_number);
            printf(",\"phoneNumber\":"); json_escape_print(p.phone);
            printf(",\"carType\":"); json_escape_print(car_type_name(p.car_type));
            printf(","); print_time_field("entryTime", p.entry_time);
            printf(",\"elapsedText\":"); json_escape_print(dur);
            printf(",\"currentFee\":%d}", fee);
        }
    }
    printf("],\"reserved\":[");
    count = count_records(RESERVATIONS_FILE, sizeof(Reservation));
    first = 1;
    for (int i = 0; i < count; i++) {
        Reservation r;
        if (read_record_at(RESERVATIONS_FILE, i, &r, sizeof(r)) == 0 && r.tower_id == tower_id && r.status == RES_RESERVED) {
            int rem = RESERVATION_TIMEOUT_SECONDS - (int)difftime(now_time(), r.reserved_at);
            if (rem < 0) rem = 0;
            if (!first) printf(",");
            first = 0;
            printf("{\"reservationNo\":"); json_escape_print(r.code);
            printf(",\"carNumber\":"); json_escape_print(r.car_number);
            printf(",\"phoneNumber\":"); json_escape_print(r.phone);
            printf(",\"carType\":"); json_escape_print(car_type_name(r.car_type));
            printf(","); print_time_field("reserveTime", r.reserved_at);
            printf(",\"limitTime\":"); char rembuf[64]; snprintf(rembuf, sizeof(rembuf), "%d분 %d초", rem / 60, rem % 60); json_escape_print(rembuf);
            printf("}");
        }
    }
    printf("]}");
}

static void action_update_entry_time(void) {
    char err[256] = "";
    char code[MAX_CODE], new_time[64];
    ParkingRecord p;
    copy_param(code, sizeof(code), "reservationNo");
    if (!*code) copy_param(code, sizeof(code), "code");
    copy_param(new_time, sizeof(new_time), "newEntryTime");
    if (!api_update_entry_time(code, new_time, &p, err, sizeof(err))) {
        print_error(err);
        return;
    }
    printf("{\"success\":true,\"reservationNo\":"); json_escape_print(p.reservation_code);
    printf(",\"carNumber\":"); json_escape_print(p.car_number);
    printf(",\"phoneNumber\":"); json_escape_print(p.phone);
    printf(","); print_time_field("entryTime", p.entry_time);
    printf("}");
}

static void action_cancel_reservation(void) {
    char err[256] = "";
    char code[MAX_CODE];
    copy_param(code, sizeof(code), "reservationNo");
    if (!*code) copy_param(code, sizeof(code), "code");
    if (!api_cancel_reservation(code, err, sizeof(err))) {
        print_error(err);
        return;
    }
    printf("{\"success\":true,\"message\":\"예약이 취소되었습니다.\"}");
}

static void action_change_reservation(void) {
    char err[256] = "";
    char code[MAX_CODE], car_type_text[64], tower_text[64];
    Reservation r;
    copy_param(code, sizeof(code), "reservationNo");
    if (!*code) copy_param(code, sizeof(code), "code");
    copy_param(car_type_text, sizeof(car_type_text), "carType");
    copy_param(tower_text, sizeof(tower_text), "towerId");
    int car_type = parse_car_type(car_type_text);
    int tower_id = parse_tower_id(tower_text);
    if (!api_change_reservation(code, car_type, tower_id, &r, err, sizeof(err))) {
        print_error(err);
        return;
    }
    char money[32]; format_money(r.deposit, money, sizeof(money));
    printf("{\"success\":true");
    print_reservation_json_fields(&r);
    printf(","); print_time_field("reserveTime", r.reserved_at);
    printf(",\"limitTime\":\"20분\",\"deposit\":"); json_escape_print(money);
    printf("}");
}

int main(void) {
    request_data = read_request();
    print_header();
    ensure_data_files();
    init_default_towers();
    srand((unsigned int)now_time());

    const char *action = get_param("action");
    if (!*action) print_error("action 값이 없습니다.");
    else if (strcmp(action, "reserve") == 0) action_reserve();
    else if (strcmp(action, "entry") == 0) action_entry();
    else if (strcmp(action, "status") == 0) action_status();
    else if (strcmp(action, "find") == 0) action_find();
    else if (strcmp(action, "settle_preview") == 0) action_settle_preview();
    else if (strcmp(action, "exit") == 0) action_exit();
    else if (strcmp(action, "fee_calc") == 0) action_fee_calc();
    else if (strcmp(action, "tower_overview") == 0) action_tower_overview();
    else if (strcmp(action, "admin_summary") == 0) action_admin_summary();
    else if (strcmp(action, "admin_tower") == 0) action_admin_tower();
    else if (strcmp(action, "update_entry_time") == 0) action_update_entry_time();
    else if (strcmp(action, "cancel_reservation") == 0) action_cancel_reservation();
    else if (strcmp(action, "change_reservation") == 0) action_change_reservation();
    else print_error("지원하지 않는 action입니다.");

    free(request_data);
    return 0;
}
